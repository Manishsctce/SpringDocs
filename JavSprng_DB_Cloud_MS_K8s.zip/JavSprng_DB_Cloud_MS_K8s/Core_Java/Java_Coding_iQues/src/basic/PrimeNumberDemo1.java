package basic;

import java.util.ArrayList;
import java.util.List;

/* Number which is not divisible by any other number 
   - Ex- 2, 3, 5, 7, 11, 13, 17 etc. 
   - 1 is not a prime number
   Be prepared for cross e.g. checking till the square root of a number etc.
 */

public class PrimeNumberDemo1 {

	static boolean isPrimeNumber(int number) { 
		if (number == 2 || number == 3)  
			return true;  
			
		if (number % 2 == 0)  
			return false;  
			
		int sqrt = (int) Math.sqrt(number) + 1; //sqrt of 144 is 12
		for (int i = 3; i < sqrt; i += 2) { 
			if (number % i == 0)
				return false; 
		} 
	return true; 
	}
	
	static List<Integer> getListOfPrimeNumber(int number) {
		List<Integer> primeNumList = new ArrayList<>();

		for (int i = 1; i <= 100; i++) {
			int counter = 0;
			for (int num = i; num >= 1; num--) {
				if (i % num == 0) {
					counter = counter + 1;
				}
			}
			if (counter == 2) {			
				primeNumList.add(i);
			}
		}

		return primeNumList;
	}
	
	public static void main(String[] args) {
		System.out.println("82 isPrimeNumber : "+isPrimeNumber(82));
		System.out.println("83 isPrimeNumber : "+isPrimeNumber(83));
		System.out.println("PrimeNumber till 100: "+getListOfPrimeNumber(100));
	}
}
