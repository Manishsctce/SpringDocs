package basic;

/* it is a String which is equal to the reverse of itself 
   - Ex- "Bob" is a palindrome because of the reverse of "Bob" is also "Bob".
 */
public class PalindromeDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
